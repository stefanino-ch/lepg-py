lep-3.27e version Windows/Linux 64bit
(2025-12-11)

Read last updates here: 
man/Updates_log.txt

lep/ contains source code and executable file
man/ contains some help files and internal data for development. New "Todo_list.odt" list.
NaN/ NaN problem solution
png/ contains captures
pre/ Pre-processor version 1.6
stl/ contains .stl surfaces
xflr5/ contains .xwimp and .dat for use with xflr5
dxf/ final edited dxf
ac/ airfoil converter

http://laboratoridenvol.com/leparagliding/manual.en.html



