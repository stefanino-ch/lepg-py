Airfoil converter
from .dat standard airfoil file to special LEP .txt airfoil file format.

http://laboratoridenvol.com/info/ac/ac.en.html