Read manual here:
http://www.laboratoridenvol.com/leparagliding/manual.en.html
http://www.laboratoridenvol.com/leparagliding/manual.ru.html

lep/ contains source code and executable files
man/ contains some help files and internal data for development
jpg/ contains some schemes
png/ contains captures
pre1.6/ Pre-processor version 1.6
stl/ contains .stl surfaces
xflr5/ contains .xwimp and .dat for use with xflr5

Updates log: man/Updates_log.txt